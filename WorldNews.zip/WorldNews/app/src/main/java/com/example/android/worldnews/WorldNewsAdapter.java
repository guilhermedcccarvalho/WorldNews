package com.example.android.worldnews;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class WorldNewsAdapter extends ArrayAdapter<WorldNews> {

    /**
     * The part of the location string from the USGS service that we use to determine
     * whether or not there is a location offset present ("5km N of Cairo, Egypt").
     */
    private static final String LOCATION_SEPARATOR = " of ";

    /**
     * Constructs a new {@link WorldNewsAdapter}.
     *
     * @param context of the app
     * @param worldNews is the list of news, which is the data source of the adapter
     */
    public WorldNewsAdapter(Context context, List<WorldNews> worldNews) {
        super(context, 0, worldNews);
    }

    /**
     * Returns a list item view that displays information about the news at the given position
     * in the list of worldNews.
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.worldnews_list_item, parent, false);
        }

        // Find the news at the given position in the list of news
        WorldNews currentNews = getItem(position);

        // Find the TextView with view ID section_name
        TextView sectionNameView = (TextView) listItemView.findViewById(R.id.section_name);
        // Display the section name of the current news in that TextView
        sectionNameView.setText(currentNews.getSectionName());

        // Find the TextView with view ID web_title
        TextView webTitleView = (TextView) listItemView.findViewById(R.id.web_title);
        // Display the title and author name of the current news in that TextView
        webTitleView.setText(currentNews.getWebTitle());

        // Find the TextView with view ID web_publication_date
        TextView webPublicationDateView = (TextView) listItemView.findViewById(R.id.web_publication_date);
        // Display the date and time of the current news in that TextView
        webPublicationDateView.setText(currentNews.getPublicationDate());

        // Return the list item view that is now showing the appropriate data
        return listItemView;
    }
}
