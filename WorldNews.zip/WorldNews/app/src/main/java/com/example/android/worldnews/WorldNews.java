package com.example.android.worldnews;

public class WorldNews {

    /** News section name */
    private String mSectionName;

    /** News title */
    private String mWebTitle;

    /** Date of news publication */
    private String mWebPublicationDate;

    /** Website URL of the earthquake */
    private String mUrl;

    /**
     * Constructs a new {@link WorldNews} object.
     *
     * @param sectionName is the name of the section where the news were published
     * @param webTitle is the title of the news with author name
     * @param webPublicationDate is the date and time of the publication
     * @param url is the website URL to find more details about the news
     */
    public WorldNews(String sectionName, String webTitle, String webPublicationDate, String url) {
        mSectionName = sectionName;
        mWebTitle = webTitle;
        mWebPublicationDate = webPublicationDate;
        mUrl = url;
    }

    /**
     * Returns the news section name.
     */
    public String getSectionName() {
        return mSectionName;
    }

    /**
     * Returns the title of the news and author name.
     */
    public String getWebTitle() {
        return mWebTitle;
    }

    /**
     * Returns the date and time of publication of the news.
     */
    public String getPublicationDate() {
        return mWebPublicationDate;
    }

    /**
     * Returns the website URL to find more information about the news.
     */
    public String getUrl() {
        return mUrl;
    }
}
